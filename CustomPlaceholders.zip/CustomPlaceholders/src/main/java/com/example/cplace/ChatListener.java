package com.example.cplace;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Замінює %назва% у чаті на значення.
 * Також ловить введення з меню (гравець пише "<назва> <значення>" у чат).
 */
public final class ChatListener implements Listener {

    private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();

    private final CustomPlaceholders plugin;
    private final PlaceholderManager manager;
    private final Set<UUID> awaiting = ConcurrentHashMap.newKeySet();

    public ChatListener(CustomPlaceholders plugin, PlaceholderManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    public void awaitInput(Player player) {
        awaiting.add(player.getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();

        if (awaiting.remove(player.getUniqueId())) {
            event.setCancelled(true);
            String text = PLAIN.serialize(event.message()).trim();
            Bukkit.getScheduler().runTask(plugin, () -> handleInput(player, text));
            return;
        }

        Component message = event.message();
        for (Map.Entry<String, String> entry : manager.getAll().entrySet()) {
            message = message.replaceText(TextReplacementConfig.builder()
                    .matchLiteral("%" + entry.getKey() + "%")
                    .replacement(manager.render(entry.getValue(), player.getName()))
                    .build());
        }
        event.message(message);
    }

    private void handleInput(Player player, String text) {
        if (text.equalsIgnoreCase("cancel")) {
            player.sendMessage("§7Додавання скасовано.");
            return;
        }

        String[] parts = text.split("\\s+", 2);
        if (parts.length < 2) {
            awaiting.add(player.getUniqueId());
            player.sendMessage("§cФормат: §f%назва% <значення>§c (або напиши cancel)");
            return;
        }

        String name = PlaceholderManager.normalize(parts[0]);
        if (!PlaceholderManager.isValidName(name)) {
            awaiting.add(player.getUniqueId());
            player.sendMessage("§cНазва: лише a-z, 0-9, _ (до 32 символів). Спробуй ще раз:");
            return;
        }

        manager.set(name, parts[1]);
        player.sendMessage("§aЗбережено плейсхолдер §f%" + name + "%");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        awaiting.remove(event.getPlayer().getUniqueId());
    }
}
