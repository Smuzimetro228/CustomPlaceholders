package com.example.cplace;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

import java.util.Locale;

/**
 * Додатково дає %cplace_<назва>% для PlaceholderAPI (скоборд, таб, інші плагіни).
 * Завантажується лише якщо PlaceholderAPI встановлено.
 */
public final class PapiHook extends PlaceholderExpansion {

    private final PlaceholderManager manager;

    public PapiHook(PlaceholderManager manager) {
        this.manager = manager;
    }

    @Override
    public String getIdentifier() {
        return "cplace";
    }

    @Override
    public String getAuthor() {
        return "CustomPlaceholders";
    }

    @Override
    public String getVersion() {
        return "1.0.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        String value = manager.get(params.toLowerCase(Locale.ROOT));
        if (value == null) {
            return null;
        }
        String name = (player != null && player.getName() != null) ? player.getName() : "";
        return value.replace("{player}", name);
    }
}
