package com.example.cplace;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * /cplace %назва% <значення>   — створити або змінити
 * /cplace remove %назва%       — видалити
 * /cplace list | menu | reload | help
 */
public final class PlaceholderCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBCOMMANDS = List.of("list", "remove", "menu", "reload", "help");

    private final PlaceholderManager manager;
    private final PlaceholderMenu menu;

    public PlaceholderCommand(PlaceholderManager manager, PlaceholderMenu menu) {
        this.manager = manager;
        this.menu = menu;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "help" -> sendHelp(sender);
            case "list" -> sendList(sender);
            case "menu" -> {
                if (sender instanceof Player player) {
                    menu.open(player);
                } else {
                    sender.sendMessage("§cМеню доступне лише гравцям.");
                }
            }
            case "reload" -> {
                manager.load();
                sender.sendMessage("§aКонфіг перезавантажено. Плейсхолдерів: " + manager.getAll().size());
            }
            case "remove", "del" -> remove(sender, args);
            default -> set(sender, args);
        }
        return true;
    }

    private void set(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cВикористання: §f/cplace %назва% <значення>");
            return;
        }

        String name = PlaceholderManager.normalize(args[0]);
        if (!PlaceholderManager.isValidName(name)) {
            sender.sendMessage("§cНазва може містити лише a-z, 0-9 і _ (до 32 символів).");
            return;
        }

        String value = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        boolean existed = manager.exists(name);
        manager.set(name, value);

        sender.sendMessage((existed ? "§eОновлено " : "§aСтворено ") + "§f%" + name + "%");
        sender.sendMessage("§7Превʼю: ");
        sender.sendMessage(manager.render(value, sender.getName()));
    }

    private void remove(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cВикористання: §f/cplace remove %назва%");
            return;
        }

        String name = PlaceholderManager.normalize(args[1]);
        if (manager.remove(name)) {
            sender.sendMessage("§aВидалено §f%" + name + "%");
        } else {
            sender.sendMessage("§cТакого плейсхолдера немає: §f%" + name + "%");
        }
    }

    private void sendList(CommandSender sender) {
        if (manager.getAll().isEmpty()) {
            sender.sendMessage("§7Плейсхолдерів ще немає.");
            return;
        }
        sender.sendMessage("§6Кастомні плейсхолдери (" + manager.getAll().size() + "):");
        manager.getAll().forEach((name, value) ->
                sender.sendMessage("§e%" + name + "% §7→ §f" + value));
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§6/cplace %назва% <значення> §7— створити або змінити");
        sender.sendMessage("§6/cplace remove %назва% §7— видалити");
        sender.sendMessage("§6/cplace list §7— список");
        sender.sendMessage("§6/cplace menu §7— меню");
        sender.sendMessage("§6/cplace reload §7— перезавантажити конфіг");
        sender.sendMessage("§7У значенні: §f{player} §7— нік гравця, §f&a §7— коди кольорів");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> options = new ArrayList<>(SUBCOMMANDS);
            manager.getAll().keySet().forEach(name -> options.add("%" + name + "%"));
            return filter(options, args[0]);
        }
        if (args.length == 2 && (args[0].equalsIgnoreCase("remove") || args[0].equalsIgnoreCase("del"))) {
            List<String> options = new ArrayList<>();
            manager.getAll().keySet().forEach(name -> options.add("%" + name + "%"));
            return filter(options, args[1]);
        }
        return List.of();
    }

    private static List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        return options.stream()
                .filter(o -> o.toLowerCase(Locale.ROOT).startsWith(p))
                .toList();
    }
}
