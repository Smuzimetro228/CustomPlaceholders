package com.example.cplace;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Зберігає кастомні плейсхолдери (назва -> значення) у config.yml.
 */
public final class PlaceholderManager {

    private static final Pattern NAME = Pattern.compile("[a-z0-9_]{1,32}");
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .build();

    private final JavaPlugin plugin;
    private final Map<String, String> placeholders = new LinkedHashMap<>();

    public PlaceholderManager(JavaPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        plugin.reloadConfig();
        placeholders.clear();

        ConfigurationSection section = plugin.getConfig().getConfigurationSection("placeholders");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            String value = section.getString(key);
            if (value != null && NAME.matcher(key).matches()) {
                placeholders.put(key, value);
            }
        }
    }

    private void save() {
        plugin.getConfig().set("placeholders", null);
        placeholders.forEach((name, value) -> plugin.getConfig().set("placeholders." + name, value));
        plugin.saveConfig();
    }

    /** "%Color%" -> "color" */
    public static String normalize(String raw) {
        String s = raw.trim().toLowerCase(Locale.ROOT);
        if (s.length() >= 2 && s.startsWith("%") && s.endsWith("%")) {
            s = s.substring(1, s.length() - 1);
        }
        return s;
    }

    public static boolean isValidName(String name) {
        return NAME.matcher(name).matches();
    }

    public void set(String name, String value) {
        placeholders.put(name, value);
        save();
    }

    public boolean remove(String name) {
        if (placeholders.remove(name) == null) {
            return false;
        }
        save();
        return true;
    }

    public boolean exists(String name) {
        return placeholders.containsKey(name);
    }

    public String get(String name) {
        return placeholders.get(name);
    }

    public Map<String, String> getAll() {
        return Collections.unmodifiableMap(placeholders);
    }

    /** Підставляє {player} і перетворює & коди на Adventure Component. */
    public Component render(String value, String playerName) {
        return LEGACY.deserialize(value.replace("{player}", playerName));
    }
}
