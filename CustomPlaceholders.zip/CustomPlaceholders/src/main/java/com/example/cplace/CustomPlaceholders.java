package com.example.cplace;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class CustomPlaceholders extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();

        PlaceholderManager manager = new PlaceholderManager(this);
        ChatListener chat = new ChatListener(this, manager);
        PlaceholderMenu menu = new PlaceholderMenu(this, manager, chat);
        PlaceholderCommand command = new PlaceholderCommand(manager, menu);

        PluginCommand cplace = getCommand("cplace");
        if (cplace != null) {
            cplace.setExecutor(command);
            cplace.setTabCompleter(command);
        }

        getServer().getPluginManager().registerEvents(chat, this);
        getServer().getPluginManager().registerEvents(menu, this);

        if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new PapiHook(manager).register();
            getLogger().info("PlaceholderAPI знайдено: доступно %cplace_<назва>%");
        }

        getLogger().info("Завантажено плейсхолдерів: " + manager.getAll().size());
    }
}
