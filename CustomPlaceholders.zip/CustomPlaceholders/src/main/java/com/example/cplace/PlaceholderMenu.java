package com.example.cplace;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * GUI зі списком плейсхолдерів.
 * ЛКМ по предмету — превʼю в чаті, ПКМ — видалити, зелений блок — додати.
 */
public final class PlaceholderMenu implements Listener {

    private static final String TITLE = "§8Кастомні плейсхолдери";
    private static final int SIZE = 54;
    private static final int ITEM_SLOTS = 45;
    private static final int ADD_SLOT = 49;

    private final CustomPlaceholders plugin;
    private final PlaceholderManager manager;
    private final ChatListener chat;

    public PlaceholderMenu(CustomPlaceholders plugin, PlaceholderManager manager, ChatListener chat) {
        this.plugin = plugin;
        this.manager = manager;
        this.chat = chat;
    }

    public void open(Player player) {
        Holder holder = new Holder();
        Inventory inventory = Bukkit.createInventory(holder, SIZE, TITLE);
        holder.inventory = inventory;

        int slot = 0;
        for (Map.Entry<String, String> entry : manager.getAll().entrySet()) {
            if (slot >= ITEM_SLOTS) {
                break;
            }
            inventory.setItem(slot, placeholderItem(entry.getKey(), entry.getValue()));
            holder.names.add(entry.getKey());
            slot++;
        }

        if (holder.names.isEmpty()) {
            inventory.setItem(22, item(Material.BARRIER, "§cПлейсхолдерів ще немає",
                    List.of("§7Натисни «Додати» внизу")));
        }

        inventory.setItem(ADD_SLOT, item(Material.LIME_DYE, "§a§lДодати плейсхолдер",
                List.of("§7Потім напиши в чат:", "§f%назва% <значення>")));

        player.openInventory(inventory);
    }

    private static ItemStack placeholderItem(String name, String value) {
        return item(Material.PAPER, "§e%" + name + "%", List.of(
                "§7Значення: " + ChatColor.translateAlternateColorCodes('&', value),
                "§8Сире: §f" + value,
                "",
                "§aЛКМ §7— превʼю в чаті",
                "§cПКМ §7— видалити"
        ));
    }

    private static ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof Holder holder)) {
            return;
        }
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getRawSlot();
        if (slot < 0 || slot >= SIZE) {
            return;
        }

        if (slot == ADD_SLOT) {
            player.closeInventory();
            chat.awaitInput(player);
            player.sendMessage("§aНапиши в чат: §f%назва% <значення>§a. Або §fcancel§a щоб скасувати.");
            return;
        }

        if (slot >= holder.names.size()) {
            return;
        }

        String name = holder.names.get(slot);
        if (event.isRightClick()) {
            manager.remove(name);
            player.sendMessage("§cВидалено §f%" + name + "%");
            Bukkit.getScheduler().runTask(plugin, () -> open(player));
        } else {
            String value = manager.get(name);
            if (value != null) {
                player.sendMessage("§7Превʼю: ");
                player.sendMessage(manager.render(value, player.getName()));
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof Holder) {
            event.setCancelled(true);
        }
    }

    /** Ідентифікує наше меню і зберігає порядок назв по слотах. */
    private static final class Holder implements InventoryHolder {
        private Inventory inventory;
        private final List<String> names = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }
}
